-- Q.3.1: Create Student table
CREATE TABLE Student (
    StudentID INT PRIMARY KEY,
    StudentName VARCHAR(50),
    StudentSurname VARCHAR(50),
    StudentNumber INT
);

-- Q.3.2: Create Lecturer table
CREATE TABLE Lecturer (
    LecturerID INT PRIMARY KEY,
    LecturerName VARCHAR(50),
    LecturerSurname VARCHAR(50)
);

-- Q.3.3: Create Tutorial table
CREATE TABLE Tutorial (
    TutorialID INT PRIMARY KEY,
    StudentID INT,
    LecturerID INT,
    TutorialDate DATE,
    TutorialTime TIME,
    TutorialDuration INT,
    FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
    FOREIGN KEY (LecturerID) REFERENCES Lecturer(LecturerID)
);

-- Q.3.4: Insert data
-- Insert Students
INSERT INTO Student (StudentID, StudentName, StudentSurname, StudentNumber)
VALUES 
(1, 'Debbie', 'Theart', 123456),
(2, 'Thomas', 'Duncan', 654321);

-- Insert Lecturers
INSERT INTO Lecturer (LecturerID, LecturerName, LecturerSurname)
VALUES 
(1, 'Zintle', 'Nukani'),
(2, 'Ravi', 'Maharaj');

-- Insert Tutorials
INSERT INTO Tutorial (TutorialID, TutorialDate, TutorialTime, TutorialDuration, LecturerID, StudentID)
VALUES 
(1, '2025-01-15', '9:00:00', 180, 2, 1),
(2, '2025-01-18', '15:00:00', 240, 2, 2),
(3, '2025-01-20', '10:00:00', 180, 1, 1),
(4, '2025-01-21', '11:00:00', 180, 2, 1);

-- Q.3.5: Tutorials between 2025-01-16 and 2025-01-20 (inclusive)
SELECT TutorialID, TutorialDate, TutorialTime, TutorialDuration, LecturerID, StudentID
FROM Tutorial
WHERE TutorialDate BETWEEN '2025-01-16' AND '2025-01-20';

-- Q.3.6: Student tutorial counts (descending order)
SELECT 
    s.StudentName,
    s.StudentSurname,
    COUNT(t.TutorialID) AS TotalTutorials
FROM Student s
LEFT JOIN Tutorial t ON s.StudentID = t.StudentID
GROUP BY s.StudentID
ORDER BY TotalTutorials DESC;

-- Q.3.7: View for students with LecturerID 2 (sorted by surname)
CREATE VIEW StudentsWithLecturer2 AS
SELECT DISTINCT
    s.StudentName,
    s.StudentSurname
FROM Student s
JOIN Tutorial t ON s.StudentID = t.StudentID
WHERE t.LecturerID = 2
ORDER BY s.StudentSurname ASC;